package de.heldenborder;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class HeldenBorderPlugin extends JavaPlugin {

    static final class Edge {
        double w, l, tw, tl;
        long start, dur;

        double f(long now) {
            return dur <= 0 ? 1 : Math.max(0, Math.min(1, (now - start) / (double) dur));
        }
        double cw(long now) { return w + (tw - w) * f(now); }
        double cl(long now) { return l + (tl - l) * f(now); }
    }

    private final Map<String, Edge> edges = new LinkedHashMap<>();
    private String worldName;
    private double sideWidth, trenchHalf;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        worldName = getConfig().getString("world", "helden");
        sideWidth = getConfig().getDouble("side-width", 4000);
        trenchHalf = getConfig().getDouble("trench-half", 112);
        for (String s : List.of("west", "east")) {
            Edge e = new Edge();
            String p = "borders." + s + ".";
            e.w = getConfig().getDouble(p + "w", sideWidth);
            e.l = getConfig().getDouble(p + "l", 20000);
            e.tw = getConfig().getDouble(p + "tw", e.w);
            e.tl = getConfig().getDouble(p + "tl", e.l);
            e.start = getConfig().getLong(p + "start", 0);
            e.dur = getConfig().getLong(p + "dur", 0);
            edges.put(s, e);
        }
        Bukkit.getScheduler().runTaskTimer(this, this::enforce, 40L, 2L);
    }

    private void persist() {
        for (Map.Entry<String, Edge> en : edges.entrySet()) {
            String p = "borders." + en.getKey() + ".";
            Edge e = en.getValue();
            getConfig().set(p + "w", e.w);
            getConfig().set(p + "l", e.l);
            getConfig().set(p + "tw", e.tw);
            getConfig().set(p + "tl", e.tl);
            getConfig().set(p + "start", e.start);
            getConfig().set(p + "dur", e.dur);
        }
        saveConfig();
    }

    // ------------------------------------------------------------------ Geometrie

    /** Erlaubte Rechtecke {minX, maxX, minZ, maxZ}: West, Ost und der freie Bereich dazwischen (inkl. Graben). */
    private List<double[]> zones(long now) {
        Edge we = edges.get("west"), ea = edges.get("east");
        double c = trenchHalf + sideWidth / 2.0;
        double ww = we.cw(now), wl = we.cl(now), ew = ea.cw(now), el = ea.cl(now);
        double wMin = -c - ww / 2, wMax = -c + ww / 2, eMin = c - ew / 2, eMax = c + ew / 2;
        List<double[]> z = new ArrayList<>();
        z.add(new double[]{wMin, wMax, -wl / 2, wl / 2});
        z.add(new double[]{eMin, eMax, -el / 2, el / 2});
        if (wMax < eMin) {
            double m = Math.max(wl, el) / 2;
            z.add(new double[]{wMax, eMin, -m, m});
        }
        return z;
    }

    private static double clamp(double v, double a, double b) {
        return a > b ? (a + b) / 2 : Math.max(a, Math.min(b, v));
    }

    /** Liefert null, wenn (x,z) erlaubt ist, sonst den naechsten erlaubten Punkt. */
    private double[] nearest(double x, double z, long now) {
        double best = Double.MAX_VALUE;
        double[] res = null;
        for (double[] r : zones(now)) {
            if (x >= r[0] && x <= r[1] && z >= r[2] && z <= r[3]) return null;
            double nx = clamp(x, r[0] + 0.5, r[1] - 0.5);
            double nz = clamp(z, r[2] + 0.5, r[3] - 0.5);
            double d = Math.hypot(nx - x, nz - z);
            if (d < best) {
                best = d;
                res = new double[]{nx, nz};
            }
        }
        return res;
    }

    private void enforce() {
        World w = Bukkit.getWorld(worldName);
        if (w == null) return;
        long now = System.currentTimeMillis();
        for (Player p : w.getPlayers()) {
            if (p.hasPermission("hborder.bypass")) continue;
            Location l = p.getLocation();
            double[] n = nearest(l.getX(), l.getZ(), now);
            if (n == null) continue;
            double y = l.getY();
            if (Math.hypot(n[0] - l.getX(), n[1] - l.getZ()) > 6) { // weit weg (z.B. Login) -> sicheren Boden suchen
                Block top = w.getHighestBlockAt((int) Math.floor(n[0]), (int) Math.floor(n[1]));
                if (!top.getType().isAir()) y = top.getY() + 1;
            }
            if (p.isInsideVehicle()) p.leaveVehicle();
            p.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
            p.teleportAsync(new Location(w, n[0], y, n[1], l.getYaw(), l.getPitch()));
            p.sendActionBar(net.kyori.adventure.text.Component.text("Du hast die Weltgrenze erreicht.",
                    net.kyori.adventure.text.format.NamedTextColor.RED));
        }
    }

    // ------------------------------------------------------------------ Befehl

    private static final Pattern DUR = Pattern.compile("^(\\d+(?:\\.\\d+)?)([smhd]?)$");

    private static long parseDuration(String s) {
        Matcher m = DUR.matcher(s.toLowerCase());
        if (!m.matches()) return -1;
        double v = Double.parseDouble(m.group(1));
        return switch (m.group(2)) {
            case "m" -> (long) (v * 60_000);
            case "h" -> (long) (v * 3_600_000);
            case "d" -> (long) (v * 86_400_000);
            default -> (long) (v * 1000);
        };
    }

    private List<Edge> pick(String arg) {
        if (arg == null || arg.equalsIgnoreCase("both")) return new ArrayList<>(edges.values());
        Edge e = edges.get(arg.toLowerCase());
        return e == null ? null : List.of(e);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("hborder.admin")) {
            sender.sendMessage("Keine Berechtigung.");
            return true;
        }
        long now = System.currentTimeMillis();
        String sub = args.length == 0 ? "info" : args[0].toLowerCase();
        try {
            switch (sub) {
                case "info" -> {
                    for (Map.Entry<String, Edge> en : edges.entrySet()) {
                        Edge e = en.getValue();
                        String extra = e.f(now) < 1 ? String.format(" -> Ziel %.0f x %.0f (noch %d s)", e.tw, e.tl,
                                (e.start + e.dur - now) / 1000) : "";
                        sender.sendMessage(String.format("%s: %.0f breit (X) x %.0f lang (Z)%s",
                                en.getKey(), e.cw(now), e.cl(now), extra));
                    }
                }
                case "set" -> { // /hborder set <breite> <laenge> [west|east|both]
                    double w = Double.parseDouble(args[1]), l = Double.parseDouble(args[2]);
                    List<Edge> list = pick(args.length > 3 ? args[3] : null);
                    if (list == null || w < 10 || l < 10) throw new IllegalArgumentException();
                    for (Edge e : list) {
                        e.w = e.tw = w;
                        e.l = e.tl = l;
                        e.dur = 0;
                    }
                    persist();
                    sender.sendMessage("Border gesetzt auf " + w + " x " + l + ".");
                }
                case "resize" -> { // /hborder resize <breite> <laenge> <dauer> [west|east|both]
                    double w = Double.parseDouble(args[1]), l = Double.parseDouble(args[2]);
                    long dur = parseDuration(args[3]);
                    List<Edge> list = pick(args.length > 4 ? args[4] : null);
                    if (list == null || dur <= 0 || w < 10 || l < 10) throw new IllegalArgumentException();
                    for (Edge e : list) {
                        e.w = e.cw(now);
                        e.l = e.cl(now);
                        e.tw = w;
                        e.tl = l;
                        e.start = now;
                        e.dur = dur;
                    }
                    persist();
                    sender.sendMessage("Border veraendert sich langsam auf " + w + " x " + l + " in " + dur / 1000 + " s.");
                }
                case "stop" -> {
                    for (Edge e : edges.values()) {
                        e.w = e.tw = e.cw(now);
                        e.l = e.tl = e.cl(now);
                        e.dur = 0;
                    }
                    persist();
                    sender.sendMessage("Veraenderung gestoppt, aktuelle Groesse bleibt.");
                }
                default -> throw new IllegalArgumentException();
            }
        } catch (RuntimeException ex) {
            sender.sendMessage("/hborder info | set <breite> <laenge> [west|east|both] | "
                    + "resize <breite> <laenge> <dauer z.B. 30m> [west|east|both] | stop");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) out.addAll(List.of("info", "set", "resize", "stop"));
        else if ((args[0].equalsIgnoreCase("set") && args.length == 4)
                || (args[0].equalsIgnoreCase("resize") && args.length == 5)) out.addAll(List.of("west", "east", "both"));
        String last = args[args.length - 1].toLowerCase();
        out.removeIf(s -> !s.startsWith(last));
        return out;
    }
}
